# tiktokLivePrinter
Live printing easy to use.

# Setup

1. Install node.js in your computer.
2. Download the TikTok Live Printer
3. Open ```cmd.exe``` and set directory to the folder containing files.
4. Run the command ```npm i``` to install all dependencies for running.
5. Run the file ```run.bat``` and open URL showing in command prompt (http://localhost:8081)
6. In the link, setup the printer
7. Run the printer
8. Enjoy
# Problems
If you have the problem "Your IP can be blocked by TikTok", you can use a VPN.
If you have any problems contact me on Discord: Il grande Stalin#3909

# Tips
In public folder you can change msg.js (containing message files) and words.js (words to guess in live).
